/**
 * 接口域名的管理
 */
 const base = {
    userList: "OA.User.GetList", //用户列表
}

export default base;