<template>
  <div class="bg-white">
      <div class="container">
          这里是品牌介绍内容<br />
          这里是品牌介绍内容
          <img src="../assets/images/logo.jpg" alt="">
          <img src="../assets/images/test/banner3.jpg" alt="">
      </div>
  </div>
</template>

<script>
export default {
    name: "brand"
}
</script>

<style scoped>
.container {
    padding: 30px 0;
    font-size: 16px;
    color: #333;
    line-height: 28px;
}
.container img {
    display: block;
    margin: 0 auto;
    max-width: 100%;
}
</style>