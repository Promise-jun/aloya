# aloya

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).


参考网站：http://www.toitoy.cn/
后台管理系统参考：https://panjiachen.gitee.io/vue-element-admin/#/dashboard
墨刀原型图：https://modao.cc/app/4af5f04d673b07b3ec3f7143bbe8c4d4fb34f95c?simulator_type=device&sticky#screen=sklohb9pygv9w4b
接口文档：https://www.showdoc.com.cn/1272522167947825?page_id=6387736329377307
